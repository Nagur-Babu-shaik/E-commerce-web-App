package com.nagur.EcommerceWebApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.nagur.EcommerceWebApp.Dao.UserRepo;
import com.nagur.EcommerceWebApp.model.User;

@Service
public class UserService {

	@Autowired
	private UserRepo repo;
	
	private BCryptPasswordEncoder encoder =new BCryptPasswordEncoder();
	public User addUser(User user) {
		// TODO Auto-generated method stub
		user.setPassword(encoder.encode(user.getPassword()));
		System.out.println(user.getPassword());
		return repo.save(user);
	}
	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		
		return repo.findAll();
				}


}
