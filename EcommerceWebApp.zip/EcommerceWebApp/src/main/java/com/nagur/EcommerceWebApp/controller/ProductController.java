package com.nagur.EcommerceWebApp.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.nagur.EcommerceWebApp.model.Product;
import com.nagur.EcommerceWebApp.service.ProductService;

@RestController
@RequestMapping("/api/product")
public class ProductController {

	@Autowired
	private ProductService service;
	
	@GetMapping("/search/{id}")
	public ResponseEntity<Product> searchProduct(@PathVariable int id){
		Product p=service.searchProduct(id);
		return new ResponseEntity<>(p,HttpStatus.OK);
		
	}
	
	@GetMapping("/display")
	public ResponseEntity<List<Product>> displayAll(){
		return new ResponseEntity<>(service.displayAll(),HttpStatus.OK);
	}
	@PutMapping("/update/{ProductId}")
	public ResponseEntity<?> updateProduct(@PathVariable int ProductId ,@RequestPart Product product,@RequestPart MultipartFile imageFile){
			try {
				Product existingProduct=service.getProductById(ProductId);
				existingProduct.setImageName(imageFile.getOriginalFilename());
				existingProduct.setImageType(imageFile.getContentType());
				existingProduct.setImageData(imageFile.getBytes());
				existingProduct.setName(product.getName());
				existingProduct.setDescription(product.getDescription());
				existingProduct.setBrand(product.getBrand());
				existingProduct.setCategory(product.getCategory());
				existingProduct.setPrice(product.getPrice());
				existingProduct.setQuantity(product.getQuantity());		
				Product updated= service.updateProduct(existingProduct);
				return new ResponseEntity<>(updated,HttpStatus.OK);
			} catch (Exception e) {
		        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		    }
	}

	
	@PostMapping("/add")
	public ResponseEntity<?> addProduct(@RequestPart Product product, @RequestPart MultipartFile imageFile){
		
		Product SavedProduct=null;
		
		try {
			SavedProduct= service.addproduct(product,imageFile);
			return new ResponseEntity<>(SavedProduct,HttpStatus.CREATED);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			return new ResponseEntity<>(e.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		
	}
	
	@DeleteMapping("/delete/{ProductId}")
	public ResponseEntity<Void> deleteById(@PathVariable int ProductId){
		
		service.deleteById(ProductId);
		return ResponseEntity.noContent().build();
		
	}
	
	
}
