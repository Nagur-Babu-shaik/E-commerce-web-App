package com.nagur.EcommerceWebApp.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.nagur.EcommerceWebApp.Dao.ProductRepo;
import com.nagur.EcommerceWebApp.model.Product;

import jakarta.transaction.Transactional;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepo repo;

	public Product searchProduct(int id) {
		// TODO Auto-generated method stub
		return repo.findById(id).orElse(new Product());
	}

	@Transactional
	public Product addproduct(Product product, MultipartFile imageFile) throws IOException {
		// TODO Auto-generated method stub
		
		product.setImageName(imageFile.getOriginalFilename());
		product.setImageType(imageFile.getContentType());
		product.setImageData(imageFile.getBytes());

		return repo.save(product);
	}

	public List<Product> displayAll() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	public Product getProductById(int ProductId) {
	    return repo.findById(ProductId)
	            .orElseThrow(() -> new RuntimeException("Product not found"));
	}

	public Product updateProduct(Product product) {
	    return repo.save(product);
	}

	public void deleteById(int productId) {
		// TODO Auto-generated method stub
		repo.deleteById(productId);
	}


	
	
}
