package com.nagur.EcommerceWebApp.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nagur.EcommerceWebApp.model.Product;

@Repository
public interface ProductRepo extends JpaRepository<Product, Integer>{
	
	

}
