package com.nagur.EcommerceWebApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nagur.EcommerceWebApp.Dao.CartRepo;
import com.nagur.EcommerceWebApp.Dao.ProductRepo;
import com.nagur.EcommerceWebApp.Dao.UserRepo;
import com.nagur.EcommerceWebApp.model.Cart;
import com.nagur.EcommerceWebApp.model.Product;
import com.nagur.EcommerceWebApp.model.User;

@Service
public class CartService {

	@Autowired
	private CartRepo repo;
	
	@Autowired
	private ProductRepo productrepo;
	
	@Autowired
	private UserRepo userrepo;
	public List<Cart> getCartItems(int userId) {
		// TODO Auto-generated method stub
		return repo.findByUserId(userId);
	}

	public Cart addToCart(Cart cart) {
		 Product product=productrepo.findById(cart.getProduct().getProductId()).orElseThrow(()-> new RuntimeException("Product not found"));
		 User user=userrepo.findById(cart.getUser().getUserId()).orElseThrow(()-> new RuntimeException("User not found"));

		cart.setProduct(product);
		cart.setUser(user);
		return repo.save(cart);
		
	}

	public  void removeFromCart(int id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
	}

}
